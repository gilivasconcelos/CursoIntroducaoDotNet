﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dia_04_Ativ_03
{
    class Aluno: Pessoa
    {
        #region Propriedades

        public int Nota { get; set; }

        #endregion

        #region Métodos

        //override exemplo
        public override string Imprimir()
        {
            return base.Imprimir()
                + "\nEstado: " + Estado.Descricao +
                  "\nNota: " + Nota;
        }

        #endregion Métodos
    }
}
