﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dia_04_Ativ_03
{
    class Professor
    {
        #region Propriedades
        public double Salario { get; set; }
        #endregion
    }
}
