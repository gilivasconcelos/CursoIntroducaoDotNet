﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dia_04_Ativ_03
{
    class Program
    {
        static void Main(string[] args)
        {
            Aluno aluno1 = new Aluno()
            {
                Id = 1,
                Nome = "Aluno 1",
                Nota = 7,
                Estado = new Estado() { Id = 1, Descricao = "São Paulo" }
            };

            Aluno aluno2 = new Aluno()
            {
                Id = 2,
                Nome = "Aluno 2",
                Nota = 10,
                Estado = new Estado() { Id = 2, Descricao = "Rio de Janeiro" }
            };


            List<Aluno> lstAluno = new List<Aluno>();

            lstAluno.Add(aluno1);
            lstAluno.Add(aluno2);

            foreach (Aluno aluno in lstAluno)
            {
                Console.WriteLine(aluno.Imprimir());
            }

            Console.ReadKey();
        }
    }
}
