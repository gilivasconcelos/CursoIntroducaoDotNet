﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dia_04_Ativ_03
{
    abstract class Pessoa
    {
        #region Propriedades
        public int Id { get; set; }

        public string Nome { get; set; }

        public Estado Estado { get; set; }

        #endregion Propriedades

        #region Métodos

        //override exemplo
        public virtual string Imprimir()
        {
            return "Id: " + Id + "\nNome: " + Nome;
        }
        #endregion Métodos
    }
}
