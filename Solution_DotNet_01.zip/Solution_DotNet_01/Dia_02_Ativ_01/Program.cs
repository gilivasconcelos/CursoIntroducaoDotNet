﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dia_02_Ativ_01
{
    class Program
    {
        static void Main(string[] args)
        {
            //switch (ArgumentoDeTeste)
            //{
            //    case ExpressãoDoValor1:
            //        //Código a executar
            //        break;
            //    case ExpressãoDoValor2:
            //        //Código a executar
            //        break;
            //    default:
            //        /*Código a executar, se nenhuma condição anterior for verdadeira*/
            //        break;
            //}


            string opcao = "";
            double valor_um = 0;
            double valor_dois = 0;

            Console.WriteLine("Entre com o 1º valor");

            valor_um = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Entre com o 2º valor");
            valor_dois = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("1-Soma");
            Console.WriteLine("2-Subtração");
            opcao = Console.ReadLine();

            switch (opcao)
            {
                case "1":
                    Console.WriteLine(" A soma é:" + (valor_um + valor_dois));
                    break;
                case "2":
                    Console.WriteLine(" A subtração é:" + (valor_um - valor_dois));
                    break;
            }

            //Apenas para ler uma tecla afim de parar a execuçõa e vermos o conteudo da tela, antes que feche
            Console.ReadKey();

        }
    }
}
