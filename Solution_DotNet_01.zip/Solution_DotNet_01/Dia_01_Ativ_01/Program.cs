﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dia_01_Ativ_01
{
    class Program
    {
        static void Main(string[] args)
        {
            int dois = 2;
            string a = "Olá";
            String b = " Mundo x";

            Console.WriteLine($"Alo {b}");

            char c = '!';
            Console.WriteLine(b + c);
            Console.ReadKey();

            //comentário aqui, linha única

            /*Bloco de comentário
             *Bloco de comentário         
             *Bloco de comentário
             */

            #region Comandos de decisão

            //If em linha única
            int num_01 = 2;
            if (num_01 > 1)  System.Console.WriteLine("Condição verdadeira!");


            //If ternário
            string mensagem = (num_01 > 1) ? "Executa aqui se condição verdadeira": "Senãop executa aqui condição falsa";
            Console.WriteLine(mensagem);

            //If tradicional
            
            if (num_01 > 1)
            {
                 mensagem = "Condição verdadeira!";
                Console.WriteLine(mensagem); ;
            }

            #endregion Comandos de decisão
            Console.ReadKey();

        }
    }
}
