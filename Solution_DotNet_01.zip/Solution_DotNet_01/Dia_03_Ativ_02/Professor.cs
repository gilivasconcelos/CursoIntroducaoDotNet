﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dia_03_Ativ_02
{
    public class Professor: Funcionario
    {
        public Professor(double salario_inicial)
        {
            this.SetSalario(salario_inicial);

        }

        public Professor()
        {           

        }

        private string disciplina;

        public string GetDisciplina ()
        {
            return disciplina;
        }

        public void SetDisciplina(string valor)
        {
            disciplina = valor;
        }
    }
}
