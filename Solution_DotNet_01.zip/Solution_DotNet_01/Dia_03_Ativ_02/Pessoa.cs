﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dia_03_Ativ_02
{
    public class Pessoa
    {
        private string nome;
        private string sexo;
        private int idade;
        public string GetNome()
        {
            return nome;
        }

        public void SetNome(string valor)
        {
            nome = valor;
        }

        public string GetSexo()
        {
            return sexo;
        }

        public void SetSexo(string valor)
        {
            sexo = valor;
        }

        public int GetIdade()
        {
            return idade;
        }

        public void SetIdade(int valor)
        {
            idade = valor;
        }
    }
}
