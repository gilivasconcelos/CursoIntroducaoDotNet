﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dia_03_Ativ_02
{
    public class Funcionario :Pessoa
    {
        private int cod_funcionario;
        private double salario;

        public int GetCod_Funcionario()
        {
            return cod_funcionario;
        }

        public void SetCod_Funcionario(int valor)
        {
            cod_funcionario = valor;
        }

        public double GetSalario()
        {
            return salario;
        }

        public void SetSalario(double valor)
        {
            salario = valor;
        }
    }
}
