﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dia_03_Ativ_02
{
    public class Diretor : Funcionario
    {
        public Diretor(Diretor Dir)
        {
            this.SetSalario(Dir.GetSalario());

        }


        public Diretor()
        {

        }

        private string escola_gerenciada;

        public string GetEscola_gerenciada()
        {
            return escola_gerenciada;
        }

        public void SetEscola_gerenciada(string valor)
        {
            escola_gerenciada = valor;
        }
    }
}
