﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dia_03_Ativ_02
{
    public class Impressao
    {
       public void Imprime()
        {
            Professor profe = new Professor(3000.00);
            Console.WriteLine("O salario Inicial de um professor é de:" + profe.GetSalario());

            Diretor diret_aux = new Diretor();
            diret_aux.SetSalario(5000);

            Diretor diret = new Diretor(diret_aux);
          
            Console.WriteLine("\n O salario Inicial de um diretor é de:" + diret.GetSalario());
            
            diret.SetSalario(7000);
            Console.WriteLine("\n O novo salario do diretor é de:" + diret.GetSalario());

            profe.SetDisciplina("Lógica de Programação");
            Console.WriteLine("\n A disciplina do professor é: " + profe.GetDisciplina());

            diret.SetEscola_gerenciada("Escola Tecnica XPTO");
            Console.WriteLine("\n A escola é: " + diret.GetEscola_gerenciada());
            Console.ReadLine();
        }
    }
}
