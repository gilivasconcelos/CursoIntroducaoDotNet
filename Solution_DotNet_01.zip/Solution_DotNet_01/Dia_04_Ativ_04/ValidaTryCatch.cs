﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dia_04_Ativ_04
{
    public class ValidaTryCatch
    {
        public void Exemplo_01_Try_Catch()
        {
            try
            {
                Console.Clear();
                Console.WriteLine("\nExemplo Try Catch 01: Para continuar com o exemplo 01 digite uma tecla");
                Console.WriteLine("\nSimulará Divisão por zero");
                Console.ReadLine();
                int i = 0;
                Console.Write(10 / i);
                Console.Write("\nLog 01 registrado com sucesso! ");                

            }
            catch (DivideByZeroException )
            {
                Console.Write("\nOcorreu um exceção");

            }           
            finally
            {
                Console.Write("\nLog 02 registrado com sucesso!");
            }

           


        }

        public void Exemplo_02_Try_Catch()        {


            try
            {
                Console.Clear();
                Console.WriteLine("\nExemplo Try Catch 02: ");
                Console.WriteLine("\nSimulará Conversão inválida, espera um número. Então digite uma letra se quiser testar");
                double num = Convert.ToInt16(Console.ReadLine());
                
                Console.WriteLine("\n String convertida com sucessso: " + num);

                Console.Write("\nLog 01 registrado com sucesso! ");

            }
            catch (Exception e)
            {
                Console.Write("\nOcorreu um exceção");

            }
            finally
            {
                Console.Write("\nLog 02 registrado com sucesso!");
            }

           


        }
    }
}
