﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dia_04_Ativ_04
{
    public class Impressao
    {

        public void Imprime()
        {
            Console.WriteLine("Digite 1 para exemplo 01 do Try Catch ");
            string opcao = Console.ReadLine();
            ValidaTryCatch exempTry_Catch = new ValidaTryCatch();

            if (opcao.Equals("1"))
            {
                Console.Clear();

                Console.Clear();
                Console.WriteLine("\nDigite qualquer tecla para continuar. Exemplo 01");
                Console.ReadLine();
                exempTry_Catch.Exemplo_01_Try_Catch();


                Console.Clear();
                Console.WriteLine("\nDigite qualquer tecla para continuar. Exemplo 02");

                exempTry_Catch.Exemplo_02_Try_Catch();

                Console.ReadLine();
            }


        }
     


        
    }
}
