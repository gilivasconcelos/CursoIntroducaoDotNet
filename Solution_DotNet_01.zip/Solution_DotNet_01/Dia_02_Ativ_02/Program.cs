﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dia_02_Ativ_02
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("1");
            //Console.WriteLine("2");
            //Console.WriteLine("3");
            //Console.ReadKey();

            //for (int i = 0; i <= 2; i++)
            //{
            //    //código aqui;
            //    Console.WriteLine(i.ToString());
            //}

            Console.WriteLine("While sendo executado");
            // While
            int i = 0;
            while (i <= 3)
            {
                Console.WriteLine(i);
                i++;
            }

            Double.Parse("1");
                Convert.ToDouble("1");

            Console.ReadKey();

            Console.WriteLine("Do While sendo executado");
            //Do While
            int x = 0;
            do
            {
                Console.WriteLine(x);

                x++;
            } while (x <= 3);


            Console.ReadKey();
        }
    }
}
