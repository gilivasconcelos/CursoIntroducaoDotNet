﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dia_05_Porva_01_Tarde
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Animal> lstAnimal_01 = new List<Animal>();
            List<Animal> lstAnimal_02 = new List<Animal>();
            Animal a1 = new Animal()
            {
                Codigo = 1,
                Nome = "Nino",
                Raca = new Raca() { Id = 1, Descricao = "Viralata" }
            };
            a1.Codigo = 1;
            Animal a2 = new Animal()
            {
                Codigo = 2,
                Nome = "Bili",
                Raca = new Raca() { Id = 2, Descricao = "Pastor Alemão" }
            };
            a2.Codigo = 1;
            lstAnimal_02.Add(a1);
            lstAnimal_01.Add(a2);
            foreach (Animal item in lstAnimal_01)
            {
                Console.WriteLine("ID: " + item.Codigo);
                Console.WriteLine("Nome: " + item.Nome);
                Console.WriteLine("Raça: " + item.Raca);
            }
            Console.ReadKey();
        }
    }
}
