﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dia_05_Porva_01_Tarde
{
  public class Animal
    {
        #region Propriedades

        public int Codigo { get; set; }
        public string Nome { get; set; }
        public Raca Raca { get; set; }

        #endregion
    }
}
