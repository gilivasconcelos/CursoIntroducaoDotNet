﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dia_04_Ativ_01
{
    public class Cliente: Pessoa
    {
        #region Propriedades
        public int Idade { get; set; }
        #endregion
    }
}
