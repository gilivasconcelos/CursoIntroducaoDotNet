﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dia_04_Ativ_01
{
    public abstract class Pessoa
    {

        #region Propriedades

        public int Id { get; set; }
        public string Nome { get; set; }
        public string Telefone { get; set; }

        #endregion 

        #region Métodos
        //virtual
        public virtual string Imprimir()
        {
            return "Id: " + this.Id + "\nNome: "
                + this.Nome + "\nTelefone: "
                + this.Telefone;
        }

        #endregion
    }
}
