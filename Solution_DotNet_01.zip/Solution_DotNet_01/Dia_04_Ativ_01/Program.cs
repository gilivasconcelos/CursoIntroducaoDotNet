﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dia_04_Ativ_01
{
    class Program
    {
        static void Main(string[] args)
        {
            Funcionario func = new Funcionario();

            func.Id = 1;
            func.Nome = "José Silva";
            func.Salario = 1000;
            func.Telefone = "16 1234-5678";

            Cliente clie = new Cliente();
            clie.Id = 1;
            clie.Nome = "Antonio Bruno";
            clie.Idade = 18;
            clie.Telefone = "16 4323-9876";

            //Imprimir
            Console.WriteLine(func.Imprimir());
            Console.WriteLine("****************");

            Console.WriteLine(clie.Imprimir());
            Console.WriteLine("Fim da exibição");

            Console.ReadKey();

        }
    }
}
