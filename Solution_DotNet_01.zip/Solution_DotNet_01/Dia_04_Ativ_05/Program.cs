﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dia_04_Ativ_05
{
    class Program
    {
        static void Main(string[] args)
        {

			Funcionario f = new Funcionario();
			Console.WriteLine("O funcionario está presente(S / N) ? ");
            string retorno = Console.ReadLine();
            f.IsPresent = verificarRetorno(retorno);

			Console.WriteLine(Imprimir(f.IsPresent));
			Console.ReadKey();		


        }

        private static string Imprimir(bool presente)
        {
            if (presente)
                return "OK, ele está presente";
            else
                return "Erro, ele não está presente";

            }

        private static bool verificarRetorno(string retorno)
        {
            if (retorno.Equals("S") || retorno.Equals("s"))
            {
                return true;
            }
            else if (retorno.Equals("N") || retorno.Equals("n"))

            {
                return false;
            }
            else
            {
                Console.WriteLine("Erro, opção inválida!");
                Console.Clear();
                Console.WriteLine("O funcionario está presente(S / N) ? ");
                string valor = Console.ReadLine();                
                return verificarRetorno(valor);

            }
        }


    }
}
