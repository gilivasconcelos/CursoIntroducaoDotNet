﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dia_04_Ativ_05
{
    public class Funcionario : Pessoa
    {
        #region Propriedades
        public double Salario { get; set; }
        public bool IsPresent { get; set; }
        #endregion

        #region Métodos
        //overring
        public override string Imprimir()
        {
            return "Id: " + this.Id + "\nNome: "
                + this.Nome + "\nTelefone: "
                + this.Telefone + "\nSalario: "
                + this.Salario;
        }

        

        #endregion
    }
}
