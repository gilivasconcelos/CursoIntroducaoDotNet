﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dia_02_Ativ_03;

namespace Dia_03_Ativ_01
{
    class Program
    {
        static void Main(string[] args)
        {
            string num_um = "";
            string opcao = "";
            Calcula obj_calc = new Calcula();

            Console.WriteLine("Enter com o 1º valor:");
            num_um = Console.ReadLine();

            obj_calc.SetValorA(Double.Parse(num_um));

            Console.WriteLine("Enter com o 2º valor:");
            obj_calc.ValorB = Double.Parse(Console.ReadLine());

            Console.WriteLine("Enter com o 3º valor:");
            obj_calc.ValorC = Double.Parse(Console.ReadLine());
            Console.WriteLine("1- Metodo Somar 01");
            Console.WriteLine("2- Metodo Somar 02");
            Console.WriteLine("3- Metodo Subtrair");
            opcao = Console.ReadLine();

            switch (opcao)
            {
                case "1":
                    Console.WriteLine("Resultado: " + obj_calc.Somar());
                        break;                   
                case "2":
                    Console.WriteLine("Resultado: " + obj_calc.Somar(obj_calc.GetValorA(), obj_calc.ValorB, obj_calc.ValorC));
                   break;
                case "3":
                    Console.WriteLine("Resultado: " + obj_calc.Subtrair());
                    break;
            }

            Console.ReadLine();
        }
    }
}
