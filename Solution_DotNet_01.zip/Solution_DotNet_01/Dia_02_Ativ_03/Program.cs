﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dia_02_Ativ_03
{
    class Program
    {
        static void Main(string[] args)
        {

            Calcula calc = new Calcula();
            var x = 10;
            //obetendo o calor da variavel x. E depois atribuir na varivel y
            double y = x;

            //Jeitos diferentes de obter o valor em uma variavel. E depois atribuir na varivel y
            y = calc.GetValorA();
            y = calc.ValorB;
            y = calc.ValorC;

            //atribuição de valor a variavel
            x = 10;
            //Jeitos diferentes de atribuir o valor
            calc.SetValorA(10);
            calc.ValorB = 10;
            calc.ValorC = 3;

            calc.SetValorA(10);

            Console.WriteLine(calc.GetValorA());

            //sem passagem de parametro
            Console.WriteLine(calc.Somar());
            //com passagem de parametro
            Console.WriteLine("\n" + calc.Somar(11, 3, 7));
            Console.ReadKey();





        }
    }
}
