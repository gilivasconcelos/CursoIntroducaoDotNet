﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dia_02_Ativ_03
{
    public class Calcula
    {
        #region Atributos/Propriedades
        //assim se declara privado, faremos os metodos mais abaixo
        private double valorA;

        //assim se declara privado, faremos os metodos mais abaixo
        private double valorB;
        
        //assim se declara public e o nome maiusculo
        //get e set auto implicito
        public double ValorC { get; set; }
        #endregion

        //metodo get/obtem o valor
        public double GetValorA()
        {
            return valorA;
        }

        //metodo set/ajusta um valor
        public void SetValorA(double valor)
        {
            valorA = valor;
        }

        //get e set auto implicito
        public double ValorB
        {
            get { return valorB; }
            set { valorB = value; }
        }


        #region Metodos

        public double Somar()
        {
            return valorA + valorB + ValorC;
        }

        //overloading de metodo
        public double Somar(double x, double y, double z)
        {


            this.valorA = x;
            this.valorB = y;
            this.ValorC = z;

            return valorA + valorB;
        }

        public double Subtrair()
        {
            return (valorA - valorB ) - ValorC;
        }
        #endregion

    }
}
